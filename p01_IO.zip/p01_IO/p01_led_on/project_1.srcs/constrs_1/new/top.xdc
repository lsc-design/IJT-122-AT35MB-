############## LED define##################
set_property PACKAGE_PIN G3 [get_ports {LED_O[0]}]
set_property PACKAGE_PIN F4 [get_ports {LED_O[1]}]
set_property PACKAGE_PIN F21 [get_ports {LED_O[2]}]
set_property PACKAGE_PIN B22 [get_ports {LED_O[3]}]
set_property PACKAGE_PIN C22 [get_ports {LED_O[4]}]
set_property PACKAGE_PIN C20 [get_ports {LED_O[5]}]
set_property PACKAGE_PIN D20 [get_ports {LED_O[6]}]
set_property PACKAGE_PIN F19 [get_ports {LED_O[7]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_O[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_O[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_O[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_O[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_O[4]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_O[5]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_O[6]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_O[7]}]





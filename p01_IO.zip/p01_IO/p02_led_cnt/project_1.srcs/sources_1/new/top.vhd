----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 2021/05/04 18:33:22
-- Design Name: 
-- Module Name: top - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity top is
    Port ( CLK_50M_I    : in STD_LOGIC;
           RESET_I      : in std_logic; 
           LED_O    : out STD_LOGIC_VECTOR (7 downto 0));           
           
end top;

architecture Behavioral of top is

signal cnt : std_logic_vector(31 downto 0); 

begin
    LED_O <= not cnt(30 downto 23);
     
    process(RESET_I,CLK_50M_I)
    begin              
        if (RESET_I='0') then
            cnt <= (others=>'0');
        elsif rising_edge(CLK_50M_I) then			
            cnt <= cnt + 1;
        end if;            
    end process;

end Behavioral;
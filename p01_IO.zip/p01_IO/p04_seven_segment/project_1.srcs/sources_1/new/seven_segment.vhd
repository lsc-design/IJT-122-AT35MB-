----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    10:46:24 02/16/2014 
-- Design Name: 
-- Module Name:    seven_segment - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity seven_segment is
    Port ( S_CLK_1K : in  STD_LOGIC;
           RESET_I : in  STD_LOGIC;
           SEG_COM_O : out  STD_LOGIC_VECTOR (3 downto 0);
           SEG_DATA_O : out  STD_LOGIC_VECTOR (7 downto 0));
end seven_segment;

architecture Behavioral of seven_segment is

--   seven-segment
--   COM:   OUT   STD_LOGIC_VECTOR (3 downto 0);
--   LED:   out   STD_LOGIC_VECTOR (6 downto 0);
-- 
-- segment encoding
--      7
--     ---  
--  2 |   | 6
--     ---   <- 1
--  3 |   | 5
--     ---			*0 
--      4
function dis_fnd(cnt : integer range 0 to 15) return std_logic_vector is
variable fnd_value : std_logic_vector(7 downto 0);
	begin
		case cnt is		
			when 0 => fnd_value := X"03";				
			when 1 => fnd_value := X"9F";
			when 2 => fnd_value := X"25";
			when 3 => fnd_value := X"0D";
			when 4 => fnd_value := X"99";
			when 5 => fnd_value := X"49";
			when 6 => fnd_value := X"41";
			when 7 => fnd_value := X"1F";
			when 8 => fnd_value := X"01";
			when 9 => fnd_value := X"09";			
			when others  => fnd_value := X"11";
		end case;
		return(fnd_value);
end dis_fnd;

signal mux_cnt					: std_logic_vector(1 downto 0) := (others => '0');
signal temp						: integer range 0 to 15;
signal dit3,dit2,dit1,dit0	: integer range 0 to 10;

begin	

	process(S_CLK_1K)
	begin		
		if rising_edge (S_CLK_1K) then
			mux_cnt <= mux_cnt + 1;			
		end if;
	end process;

	process(RESET_I )
	begin		
		if(RESET_I = '0') then
			dit0 <= 0;
			dit1 <= 0;
			dit2 <= 0;
			dit3 <= 0;
		else
			dit0 <= 4;
			dit1 <= 3;
			dit2 <= 2;
			dit3 <= 1;
		end if;
	end process;
	
	process(mux_cnt)
	begin
		case mux_cnt is
			when "00" => temp <= dit0; 
						 SEG_COM_O <= "0001";
			when "01" => temp <= dit1;
						 SEG_COM_O <= "0010";						 
			when "10" => temp <= dit2;						 
						 SEG_COM_O <= "0100";
			when others => temp <= dit3;
						 SEG_COM_O <= "1000";						 			
		end case;
	end process;
	SEG_DATA_O <= dis_fnd(temp);
end Behavioral;



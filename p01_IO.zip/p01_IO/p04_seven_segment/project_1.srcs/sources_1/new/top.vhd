----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 2021/05/04 18:33:22
-- Design Name: 
-- Module Name: top - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity top is
    Port ( 	CLK_50M_I 		: in  STD_LOGIC;
			RESET_I 		: in  STD_LOGIC;	 
			TACT_KEY3_I		: in  STD_LOGIC;
----------------------------------------------------------------------------------
-- Seven-Sement Signals
----------------------------------------------------------------------------------				
			SEG_LINE_CTL_O	: out  STD_LOGIC;
			SEG_LINE_SIG_O	: out  STD_LOGIC;
			SEG_COM_O 		: out STD_LOGIC_VECTOR (3 downto 0);
			SEG_DATA_O	 	: out STD_LOGIC_VECTOR (7 downto 0));			
end top;

architecture Behavioral of top is
signal S_CLK_1K			: std_logic;
component clock_control
	Port ( 	CLK_50M_I 		: in  STD_LOGIC;				
			S_CLK_1K 		: out  STD_LOGIC);
end component;			  

component seven_segment
	port (	S_CLK_1K		: in std_logic;
			RESET_I 		: in  STD_LOGIC;			
			SEG_COM_O		: out std_logic_vector(3 downto 0);
			SEG_DATA_O		: out std_logic_vector(7 downto 0));
end component;

begin    
	clk_control : clock_control port map(
		CLK_50M_I	=> CLK_50M_I,		
		S_CLK_1K 	=> S_CLK_1K	);
	display1 : seven_segment port map(
		S_CLK_1K 	=> S_CLK_1K,		
		RESET_I		=> RESET_I,		
		SEG_COM_O 	=> SEG_COM_O,
		SEG_DATA_O 	=> SEG_DATA_O);
	
	SEG_LINE_CTL_O <= '1';	
    SEG_LINE_SIG_O <= TACT_KEY3_I;
    		
end Behavioral;
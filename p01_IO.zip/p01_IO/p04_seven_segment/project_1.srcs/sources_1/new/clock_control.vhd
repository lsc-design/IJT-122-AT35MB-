----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    14:06:12 09/09/2013 
-- Design Name: 
-- Module Name:    CLK_CON - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity clock_control is
    Port ( 	CLK_50M_I 			: in  STD_LOGIC;				
			S_CLK_1K			: out STD_LOGIC							
			  );
end clock_control;

architecture Behavioral of clock_control is

signal cnt			: integer range 0 to 65535;
signal clk_1khz		: std_logic;

component bufg
	port(
		i	: in std_logic;
		o 	: out std_logic);
end component;

begin			

	S_CLK_1K <= clk_1khz;

	process(CLK_50M_I)
	begin		
		if rising_edge(CLK_50M_I) then			
			if(cnt >= 25000)  then				
				cnt <= 0;
				clk_1khz <= not clk_1khz;
			else
				cnt <= cnt + 1;
			end if;
		end if;
	end process;	

end Behavioral;


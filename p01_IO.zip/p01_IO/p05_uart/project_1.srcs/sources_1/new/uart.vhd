library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity uart is
    port ( 	    RESET_I		: in  STD_LOGIC;								
				S_rxClk		: in  STD_LOGIC;								
				S_txClk		: in  STD_LOGIC;					
				RXD_I     	: in  std_logic;     -- RS232 receiver line
				TXD_O    	: out std_logic;    	-- RS232 transmitter line
				LED_O 		: out  STD_LOGIC_VECTOR (7 downto 0)	
			);
end uart;

architecture Behavioral of uart is

signal tx_data  				: std_logic_vector(7 downto 0);
signal rece_flag   				: std_logic;                    -- Byte received
signal tx_step  				: std_logic_vector(3 downto 0) := (others => '0');
signal rece_reg					: std_logic_vector(7 downto 0); -- receive register   
signal serial_data 				: std_logic_vector(7 downto 0) := X"20";	

begin					
	
	LED_O <= not tx_data;
	
	rxpro : process(RESET_I,S_rxClk)
	variable bit_posi : INTEGER range 0 to 10;   
	variable sample_cnt : INTEGER range 0 to 3; 
	begin
		if(RESET_I = '0') then
			rece_flag <= '0';
			bit_posi := 0;			
		elsif rising_edge(S_rxClk) then				
           case bit_posi is
              when 0 => 								-- idle
                 rece_flag <= '0';
                 if RXD_I = '0' then				-- Start Bit
                    sample_cnt := 0;
                    bit_posi := 1;
                 end if;
              when 10 => 								-- Stop Bit
                 bit_posi := 0;						-- next is idle
                 rece_flag <= '1';                  					  
					  tx_data <= rece_reg;
              when others =>
						rece_flag <= '1';  
                 if sample_cnt = 1 then		 	-- Sample RxD on 1
                    rece_reg(bit_posi-2) <= RXD_I; 	
                 end if;
                 if sample_cnt = 3 then 
                    bit_posi := bit_posi + 1;
                 end if;
           end case;
           if sample_cnt = 3 then 
              sample_cnt := 0;
           else   
              sample_cnt := sample_cnt + 1;
           end if;          
		end if;
	end process; 
	
	txpro : process(RESET_I,S_txClk,rece_flag)   
	begin
		if(RESET_I = '0') then		
			TXD_O <= '1';        
			tx_step <= (others => '0');
		elsif rising_edge(S_txClk) then 			
			if(rece_flag = '1') then		
				tx_step <= (others => '0');
			else
				if(tx_step = X"A") then
					tx_step <= tx_step;
				else
					tx_step <= tx_step + 1;
				end if;
			end if;
			
			case tx_step is
				when X"1" => TXD_O <= '0';			--start
				when X"2" => TXD_O <= tx_data(0);	--data0
				when X"3" => TXD_O <= tx_data(1);	--data1
				when X"4" => TXD_O <= tx_data(2);	--data2
				when X"5" => TXD_O <= tx_data(3);	--data3
				when X"6" => TXD_O <= tx_data(4);	--data4
				when X"7" => TXD_O <= tx_data(5);	--data5
				when X"8" => TXD_O <= tx_data(6);	--data6
				when X"9" => TXD_O <= tx_data(7);	--data7
				when others => TXD_O <= '1';			--stop
			end case;
		end if;
	end process;	
end Behavioral;


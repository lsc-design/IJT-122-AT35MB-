library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity top is
	Port (  CLK_50M_I 	: in  STD_LOGIC;
			RESET_I 	: in  STD_LOGIC;				
----------------------------------------------------------------------------------
-- UART Signals
----------------------------------------------------------------------------------								
			RXD_I 		: in  STD_LOGIC;
			TXD_O		: out  STD_LOGIC;
----------------------------------------------------------------------------------
-- LED Signals
----------------------------------------------------------------------------------
			LED_O 		: out  STD_LOGIC_VECTOR (7 downto 0));	
end top;

architecture Behavioral of top is

signal S_rxClk				: std_logic;		
signal S_txClk				: std_logic;	

component CLK_CON
    Port ( 	CLK_50M_I   : in  STD_LOGIC;				
			RESET_I 	: in  STD_LOGIC;		     		
		    S_rxClk 	: out  STD_LOGIC;
		    S_txClk 	: out  STD_LOGIC  	
		  );
end component;	

component uart
	port ( 	RESET_I			: in  STD_LOGIC;								
			S_rxClk			: in  STD_LOGIC;								
			S_txClk			: in  STD_LOGIC;				
			RXD_I     		: in  std_logic;     -- RS232 receiver line
			TXD_O    		: out std_logic;     -- RS232 transmitter line
			LED_O 			: out  STD_LOGIC_VECTOR (7 downto 0)	
			);	
end component;		

begin
	clk_control : CLK_CON port map(
		CLK_50M_I	=> CLK_50M_I,
		RESET_I     => RESET_I,  		
		S_rxClk		=> S_rxClk,
		S_txClk 	=> S_txClk
	);	

	serial_com : uart port map(				
		RESET_I 	=>	RESET_I,
		S_rxClk 	=>	S_rxClk,
		S_txClk 	=>	S_txClk,		
		RXD_I    	=>	RXD_I,
		TXD_O    	=>	TXD_O,
		LED_O		=>  LED_O
		);	
		
end Behavioral;
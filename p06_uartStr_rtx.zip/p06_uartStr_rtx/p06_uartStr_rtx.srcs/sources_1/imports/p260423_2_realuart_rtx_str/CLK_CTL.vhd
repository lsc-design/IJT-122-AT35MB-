library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_arith.all;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity CLK_CTL is
generic (
            CLK_FREQ : integer := 50_000_000; 
            BAUD_RATE : integer := 115_200;   		    		  
		    waitClk_gene : integer := 2_000_000   --1MHz		  
    );		
Port ( 	
		CLK_50M_I 	   : in  STD_LOGIC;
		RESET_I 		: in  STD_LOGIC;		
		S_clk			: out  STD_LOGIC;		
		S_rxClk 		: out  STD_LOGIC;
		S_txClk 		: out  STD_LOGIC
		);
end CLK_CTL;

architecture Behavioral of CLK_CTL is

constant baudRate_calcVal : integer := (CLK_FREQ/(BAUD_RATE*8))-1;
constant clk200k_calcVal : integer := (CLK_FREQ/waitClk_gene)-1;  	--1MHz -> 50M/1M=(50/2)-1=24, 50M/25=2,000,000

signal clkDivide_cnt	: integer range 0 to 65535;
signal clkDivide_regt	: std_logic;

signal baudRate_rxCnt		: integer range 0 to 4095;
signal baudRate_rxClk		: std_logic;	
signal baudRate_txCnt		: std_logic_vector(1 downto 0) := (others => '0');
signal baudRate_txClk		: std_logic;	

begin

	S_clk <= clkDivide_regt;	
	
	S_rxClk <= baudRate_rxClk;
	S_txClk <= baudRate_txClk;
	
	baudRate_txClk <= baudRate_txCnt(1);

	process(CLK_50M_I,RESET_I)
	begin		
		if(RESET_I = '0') then
			clkDivide_cnt <= 0;			
		elsif rising_edge(CLK_50M_I) then			
			if(clkDivide_cnt >= clk200k_calcVal)  then								
				clkDivide_cnt <= 0;
				clkDivide_regt <= not clkDivide_regt;				
			else
				clkDivide_cnt <= clkDivide_cnt + 1;				
			end if;
		end if;
	end process;		
	
	process(CLK_50M_I,RESET_I)
	begin
		if(RESET_I = '0') then
			baudRate_rxCnt <= 0;
			baudRate_rxClk <= '0';		
		elsif rising_edge(CLK_50M_I) then			
			if(baudRate_rxCnt >= baudRate_calcVal)  then				
				baudRate_rxCnt <= 0;
				baudRate_rxClk <= not baudRate_rxClk;
			else
				baudRate_rxCnt <= baudRate_rxCnt + 1;
			end if;
		end if;
	end process;

	process(baudRate_rxClk)
	begin		
		if rising_edge(baudRate_rxClk) then
			baudRate_txCnt <= baudRate_txCnt + 1;
		end if;
	end process;

end Behavioral;


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity sramCtrl is
    generic (
        ADDR_WIDTH : integer := 8; -- 15 addresses
        DATA_WIDTH : integer := 8  -- 8-bit data
    );
	 
	 Port ( 	RESET_I 			: in  STD_LOGIC;	 
				S_clk				: in STD_LOGIC;
				S_moniComplete		: in STD_LOGIC;
				ramWrite_addr		: in std_logic_vector(7 downto 0);			
				ramRead_addr		: in std_logic_vector(7 downto 0);			
				RxBuff				: in std_logic_vector(7 downto 0);
				TxBuff				: out std_logic_vector(7 downto 0)			  
			  );
end sramCtrl;

architecture Behavioral of sramCtrl is

type ram_type is array (0 to (2**ADDR_WIDTH)-1) of std_logic_vector(DATA_WIDTH-1 downto 0);
signal RAM : ram_type; 

begin
    process(S_clk)
    begin
	   if(RESET_I = '0') then
			TxBuff <= (others => '0');
	   elsif rising_edge(S_clk) then
            if(S_moniComplete = '0') then									-- write signal               
			     RAM(conv_integer(ramWrite_addr)) <= RxBuff;					
			else					
				TxBuff <= RAM(conv_integer(ramRead_addr)); 					
			end if;            
       end if;
    end process;
end behavioral;




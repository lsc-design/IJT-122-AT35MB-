----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    17:28:16 04/24/2026 
-- Design Name: 
-- Module Name:    rxFinish_moni - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity rxFinish_moni is
    generic(
				waitTime : integer := 500000	
				);
	 
	 Port ( RXD_I	 		: in  STD_LOGIC;
            RESET_I			: in  STD_LOGIC;
			S_clk			: in  STD_LOGIC;				  
            S_moniComplete 	: out  STD_LOGIC
			  );
end rxFinish_moni;

architecture Behavioral of rxFinish_moni is
 
signal moniTime_cnt : integer range 0 to 6000000:=0;

begin

	process(RESET_I,S_clk	)	
	begin
		if(RESET_I = '0') then
			moniTime_cnt <= 0;		
			S_moniComplete <= '0';			
		elsif rising_edge(S_clk) then	
			if(RXD_I = '0') then
				moniTime_cnt <= 0;
				S_moniComplete <= '0';
			else				
				if(moniTime_cnt >= waitTime)  then				
					moniTime_cnt <= moniTime_cnt;
					S_moniComplete <= '1';				
				else
					moniTime_cnt <= moniTime_cnt + 1;
					S_moniComplete <= '0';				
				end if;
			end if;	
		end if;
	end process;	
	
end Behavioral;


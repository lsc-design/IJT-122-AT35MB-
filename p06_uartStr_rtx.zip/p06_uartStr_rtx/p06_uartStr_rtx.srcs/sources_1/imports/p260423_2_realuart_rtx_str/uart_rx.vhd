library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity uart_rx is
    port ( 	RESET_I					: in  std_logic;
			S_rxClk					: in  std_logic;		
			RXD_I     				: in  std_logic;
				
			S_moniComplete			: in  std_logic;
			ramWrite_addr			: out std_logic_vector(7 downto 0);			
			ramWrite_value			: out std_logic_vector(7 downto 0);			
				
			rxStatus 				: out std_logic;
			txDataLoder				: out std_logic;
			RxBuff					: out std_logic_vector(7 downto 0)			
			);
end uart_rx;

architecture Behavioral of uart_rx is

signal rxData_reg			: std_logic_vector(7 downto 0) := (others=>'0');
signal ramWaddr_reg			: std_logic_vector(7 downto 0) := (others=>'0');

begin

	ramWrite_addr <= ramWaddr_reg;
	
	rxpro : process(RESET_I,S_rxClk)
	variable rxBit_index : INTEGER range 0 to 15;   
	variable sample_cnt : INTEGER range 0 to 3; 
	begin
		if(RESET_I = '0') then
			ramWaddr_reg <= (others=>'0');
			ramWrite_value <= (others=>'0');				
			rxStatus <= '0';
			txDataLoder <= '0'; 
			rxBit_index := 0;
			rxData_reg <= (others=>'0');		
			RxBuff <= (others=>'0');			
		elsif rising_edge(S_rxClk) then
			if(S_moniComplete = '1') then
				if(ramWaddr_reg = X"0") then
					ramWaddr_reg <= (others=>'0');
				else
					ramWrite_value <= ramWaddr_reg;
					ramWaddr_reg <= (others=>'0');					
				end if;
			else	
				case rxBit_index is
					  when 0 => 								-- idle						  
						  if RXD_I = '0' then				-- Start Bit
							  sample_cnt := 0;
							  rxBit_index := 1;							   
						  end if;
					  when 10 => 								-- Stop Bit				   		
						  rxBit_index := 11;					
						  RxBuff <= rxData_reg;							  
					  when 11 =>
							rxBit_index := 0;					-- next is idle
							ramWaddr_reg <= ramWaddr_reg + 1;							
					  when others =>						    
						  if sample_cnt = 1 then		 	-- Sample RxD on 1
							  rxData_reg(rxBit_index-2) <= RXD_I; 	
						  end if;
						  if sample_cnt = 3 then 
							  rxBit_index := rxBit_index + 1;
						  end if;
				  end case;
				  if sample_cnt = 3 then 
					  sample_cnt := 0;
				  else   
					  sample_cnt := sample_cnt + 1;
				  end if;	
			end if;		
		end if;	
	end process;
	
end Behavioral;


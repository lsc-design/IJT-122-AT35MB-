library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity uart_tx is
    Port (  RESET_I 		: in  STD_LOGIC;
		    S_moniComplete	: in STD_LOGIC;	
            S_txClk 		: in  STD_LOGIC;
            rxStatus 		: in  STD_LOGIC;
			txDataLoder 	: in  STD_LOGIC;
			ramWrite_value	: in std_logic_vector(7 downto 0);	
			TxBuff 			: in  STD_LOGIC_VECTOR (7 downto 0);
			ramRead_addr	: out  STD_LOGIC_VECTOR (7 downto 0);
            TXD_O 			: out  STD_LOGIC
			  );
end uart_tx;

architecture Behavioral of uart_tx is

CONSTANT HEX_CR	: std_logic_vector(7 DOWNTO 0)	:= "00001101";
CONSTANT HEX_LF	: std_logic_vector(7 DOWNTO 0)	:= "00001010";

signal crlfReg          : std_logic := '0';
signal crlfCnt          : std_logic_vector(7 downto 0) := (others => '0');

signal txData			: std_logic_vector(7 downto 0) := (others => '0');
signal ramRaddr_reg		: std_logic_vector(7 downto 0) := (others=>'0');
	
begin

	ramRead_addr <= ramRaddr_reg;

	txpro : process(RESET_I,S_txClk,rxStatus)
	variable txBit_index : INTEGER range 0 to 10;    
	begin
		if(RESET_I = '0') then		
			TXD_O <= '1';        
			txBit_index := 0;
			ramRaddr_reg <= (others => '0');
		elsif rising_edge(S_txClk) then
			if(S_moniComplete = '1') then				
				if(ramRaddr_reg = ramWrite_value) then
				    if(crlfReg = '1') then
				        if(crlfCnt > X"2F") then
				           crlfCnt <= crlfCnt;
				           crlfReg <= '0';     
				        else
				            crlfCnt <= crlfCnt + 1;
                        end if;				            
				        case crlfCnt is
                            when X"01" => TXD_O <= '0';			
                            when X"02" => TXD_O <= HEX_CR(0);	
                            when X"03" => TXD_O <= HEX_CR(1);	
                            when X"04" => TXD_O <= HEX_CR(2);	
                            when X"05" => TXD_O <= HEX_CR(3);	
                            when X"06" => TXD_O <= HEX_CR(4);	
                            when X"07" => TXD_O <= HEX_CR(5);	
                            when X"08" => TXD_O <= HEX_CR(6);	
                            when X"09" => TXD_O <= HEX_CR(7);	
                            when X"11" => TXD_O <= '0';			
                            when X"12" => TXD_O <= HEX_LF(0);	
                            when X"13" => TXD_O <= HEX_LF(1);	
                            when X"14" => TXD_O <= HEX_LF(2);	
                            when X"15" => TXD_O <= HEX_LF(3);	
                            when X"16" => TXD_O <= HEX_LF(4);	
                            when X"17" => TXD_O <= HEX_LF(5);	
                            when X"18" => TXD_O <= HEX_LF(6);	
                            when X"19" => TXD_O <= HEX_LF(7);                            
                            when others => TXD_O <= '1';
                        end case;				    
				    end if;				    
					ramRaddr_reg <= ramRaddr_reg;
				else
				    crlfReg <= '1';	
				    crlfCnt <= (others=>'0');
				    
					case txBit_index is
						when 0 => 									-- idle or stop bit
							TXD_O <= '1';                               
							txBit_index := 1;                 
						when 1 => 									-- Start bit
							txData <= TxBuff;           
							TXD_O <= '0';
							txBit_index := 2;											
						when 10 => 				
							TXD_O <= '1';
							txBit_index := 0;						-- stop
							ramRaddr_reg <= ramRaddr_reg + 1;							
						when others =>
							TXD_O <= txData(txBit_index-2); 		-- Serialisation of TReg
							txBit_index := txBit_index + 1;                            
					end case;				
				end if;
			else
				ramRaddr_reg <= (others => '0');				    --write mode
			end if;	
		end if;		
	end process;

end Behavioral;


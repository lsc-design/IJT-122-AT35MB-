----------------------------------------------------------------------------------
-- Company			: IjinTech
-- Engineer			:  
-- Module Name		: top - Behavioral 
-- Project Name	: 
-- Target Devices	: 
-- Additional Comments:
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity top is
	Port (   CLK_50M_I 	: in  STD_LOGIC;
			 RESET_I	: in  STD_LOGIC;		
----------------------------------------------------------------------------------
-- UART Signals
----------------------------------------------------------------------------------								
			RXD_I 		: in  STD_LOGIC;
			TXD_O		: out  STD_LOGIC;
----------------------------------------------------------------------------------
-- LED Signals
----------------------------------------------------------------------------------
			LED_O 		: out  STD_LOGIC_VECTOR (7 downto 0));	
end top;

architecture Behavioral of top is

signal S_clk			: std_logic;
signal S_moniComplete	: std_logic;


signal ramWrite_addr	: std_logic_vector(7 downto 0);
signal ramWrite_value	: std_logic_vector(7 downto 0);	
signal ramRead_addr		: std_logic_vector(7 downto 0);	

signal S_rxClk			: std_logic;		
signal S_txClk			: std_logic;
signal rxStatus 		: std_logic;
signal txDataLoder		: std_logic;
signal RxBuff			: std_logic_vector(7 downto 0) := (others=>'0');
signal txBuff			: std_logic_vector(7 downto 0) := (others=>'0');

signal clkIndi_reg 		: STD_LOGIC;

component CLK_CTL
	Port ( 	   CLK_50M_I	    : in  STD_LOGIC;
				RESET_I 		: in  STD_LOGIC;				
				S_clk			: out  STD_LOGIC;				
				S_rxClk 		: out  STD_LOGIC;
				S_txClk 		: out  STD_LOGIC
				);
end component;	

component rxFinish_moni
	 Port (    RXD_I	 		: in  STD_LOGIC;
               RESET_I 			: in  STD_LOGIC;
			   S_clk			: in  STD_LOGIC;			  
               S_moniComplete 	: out  STD_LOGIC
			  );
end component;

component sramCtrl 
	port	(   RESET_I			: in  STD_LOGIC;
				S_clk			: in STD_LOGIC;
				S_moniComplete	: in STD_LOGIC;
				ramWrite_addr	: in std_logic_vector(7 downto 0);			
				ramRead_addr	: in std_logic_vector(7 downto 0);			
				RxBuff			: in std_logic_vector(7 downto 0);
				TxBuff			: out std_logic_vector(7 downto 0)				
			  );
end component;

component uart_rx
	port (	    RESET_I         : in  STD_LOGIC;								
				S_rxClk			: in  STD_LOGIC;							
				RXD_I  	  		: in  std_logic;     				
				S_moniComplete	: in  std_logic;
				ramWrite_addr	: out std_logic_vector(7 downto 0);
				ramWrite_value	: out std_logic_vector(7 downto 0);				
				rxStatus 		: out std_logic;
				txDataLoder		: out std_logic;
				RxBuff 			: out  STD_LOGIC_VECTOR (7 downto 0)	
			);	
end component;

component uart_tx
	port (    RESET_I 			: in  STD_LOGIC;
			  S_moniComplete	: in STD_LOGIC;	
              S_txClk 			: in  STD_LOGIC;
              rxStatus 			: in  STD_LOGIC;
			  txDataLoder 		: in  STD_LOGIC;
			  ramWrite_value	: in std_logic_vector(7 downto 0);	
			  TxBuff 			: in  STD_LOGIC_VECTOR (7 downto 0);
			  ramRead_addr		: out  STD_LOGIC_VECTOR (7 downto 0);
              TXD_O				: out  STD_LOGIC
			);	
end component;

begin
	
	LED_O(7) <= not S_moniComplete;
	LED_O(6 downto 0) <= TxBuff(6 downto 0);	

	clk_control : CLK_CTL port map(
		CLK_50M_I	=> CLK_50M_I,
		RESET_I 	=> RESET_I,		
		S_clk		=> S_clk,		
		S_rxClk		=> S_rxClk,
		S_txClk 	=> S_txClk
	);	
	
	time_check : rxFinish_moni port map(
		RXD_I		   => RXD_I,
        RESET_I 	   => RESET_I,
		S_clk	 	   => S_clk,		
        S_moniComplete => S_moniComplete
		);
	
	ram_control : sramCtrl port map(
		RESET_I 		=> RESET_I,
		S_clk 			=> S_clk,
		S_moniComplete	=> S_moniComplete,
		ramWrite_addr 	=> ramWrite_addr,
		ramRead_addr 	=> ramRead_addr,
		RxBuff			=> RxBuff,
		TxBuff			=> TxBuff
		);	

	serial_rx : uart_rx port map(				
		RESET_I 		=>	RESET_I,
		S_rxClk 		=>	S_rxClk,
		RXD_I    		=>	RXD_I,				
		S_moniComplete	=> S_moniComplete,
		ramWrite_addr	=> ramWrite_addr,		
		ramWrite_value	=> ramWrite_value,
		rxStatus 		=> rxStatus,
		txDataLoder		=> txDataLoder,		
		RxBuff			=> RxBuff
		);

	serial_tx : uart_tx port map(				
		RESET_I 		=>	RESET_I,
		S_moniComplete	=> S_moniComplete,
		S_txClk 		=>	S_txClk,	
		rxStatus 		=> rxStatus,
		txDataLoder		=> txDataLoder,
		ramWrite_value	=> ramWrite_value,
		TxBuff   		=> TxBuff,
		ramRead_addr	=> ramRead_addr,	
		TXD_O			=> TXD_O
		);			
		
end Behavioral;

